﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace sdop.Models
{
    public class Buy
    {
        public int Id { get; set; }

        [ForeignKey("Company")]
        public string CompanyName { get; set; }

        [ForeignKey("Distributor")]
        public string DistributorId { get; set; }
    }
    public class BuyDBContext : DbContext
    {
        public DbSet<Buy> Buys { get; set; }
    }
}