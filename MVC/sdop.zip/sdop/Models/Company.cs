﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace sdop.Models
{
    public class Company
    {
        public int Id { get; set; }

        [Key]
        [Required]
        [StringLength(50)]
        public string CompanyName { get; set; }

        [Required]
        [StringLength(200)]
        public string HQAddress { get; set; }

        [Range(0, 999)]
        public int IncomeOutcomeB { get; set; }

        [Range(0, 200)]
        public int NumberOfSalesmen { get; set; }

        [Range(0, 200)]
        public int NumberOfFactories { get; set; }

        [Range(0, 999)]
        public double NewDrugRate { get; set; }

    }
    public class CompanyDBContext : DbContext
    {
        public DbSet<Company> Companies { get; set; }
    }
}