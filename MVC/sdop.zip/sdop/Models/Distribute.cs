﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace sdop.Models
{
    public class Distribute
    {
        public int Id { get; set; }

        [ForeignKey("Distributor")]
        public string DistributorId { get; set; }

        [Key]
        [Required]
        [Range(999999999, 9999999999)]
        public long DrugSerialCode { get; set; }

        [ForeignKey("Company")]
        [Required]
        [StringLength(50)]
        public string CompanyName { get; set; }
    }
    public class DistributeDBContext : DbContext
    {
        public DbSet<Distribute> Distributes { get; set; }
    }
}