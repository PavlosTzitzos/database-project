﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace sdop.Models
{
    public class Goto
    {
        public int Id { get; set; }

        [ForeignKey("Doctor")]
        [Required]
        [Range(0, 99999999999)]
        public long DoctorSSN { get; set; }

        [ForeignKey("Patient")]
        [Required]
        [Range(0, 99999999999)]
        public long PatientSSN { get; set; }
    }
    public class GotoDBContext : DbContext
    {
        public DbSet<Goto> GoesTo { get; set; }
    }
}