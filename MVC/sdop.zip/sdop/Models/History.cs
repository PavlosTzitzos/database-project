﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace sdop.Models
{
    public class History
    {
        public int Id { get; set; }

        [ForeignKey("Patient")]
        [Required]
        [Range(0, 99999999999)]
        public long PatientSSN { get; set; }

        [ForeignKey("Company")]
        [Required]
        public string CompanyName { get; set; }

        [ForeignKey("Drug")]
        [Required]
        [Range(999999999, 9999999999)]
        public long DrugSerialCode { get; set; }
    }
    public class HistoryDBContext : DbContext
    {
        public DbSet<History> HistoryList { get; set; }
    }
}