﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace sdop.Models
{
    public class Produce
    {
        public int Id { get; set; }

        [ForeignKey("Company")]
        [Required]
        public string CompanyName { get; set; }

        [ForeignKey("Drug")]
        [Required]
        [Range(999999999, 9999999999)]
        public long DrugSerialCode { get; set; }
    }
    public class ProduceDBContext : DbContext
    {
        public DbSet<Produce> Produces { get; set; }
    }
}