﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace sdop.Models
{
    public class Provide
    {
        public int Id { get; set; }

        [ForeignKey("Company")]
        [Required]
        [StringLength(50)]
        public string CompanyName { get; set; }

        [ForeignKey("Drug")]
        [Required]
        [Range(999999999, 9999999999)]
        public long DrugSerialCode { get; set; }

        [ForeignKey("Sdop")]
        public int SdopId { get; set; }
    }
    public class ProvideDBContext : DbContext
    {
        public DbSet<Provide> Provides { get; set; }
    }
}