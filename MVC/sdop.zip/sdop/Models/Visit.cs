﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace sdop.Models
{
    public class Visit
    {
        public int Id { get; set; }

        [ForeignKey("Salesman")]
        [Required]
        [Range(0, 99999999999)]
        public long SalesmanSSN { get; set; }

        [ForeignKey("Doctor")]
        [Required]
        [Range(0, 99999999999)]
        public long DoctorSSN { get; set; }
    }
    public class VisitDBContext : DbContext
    {
        public DbSet<Visit> Visits { get; set; }
    }
}